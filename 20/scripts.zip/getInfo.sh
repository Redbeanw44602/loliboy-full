#!/bin/bash
#cpu_status=`top -n1 | fgrep "bedrock" | tail -1 | awk -F' ' '{ printf "%s\n", $9; }'`
#mem_status=`top -n1 | fgrep "bedrock" | tail -1 | awk -F' ' '{ printf "%s\n", $10; }'`
# if [ "$1"x = "cpu"x ]
# then
while true
do
	cpu_status=`mpstat -P ALL 1 1 | fgrep "all" | tail -1 | awk -F ' ' '{ printf "%s", $3;}'`
	cpu_status=$(awk -v a=$cpu_status 'BEGIN{printf("%d",a)}')
	mem_status=`free -m | awk -F '[ :]+' 'NR==2{printf "%d", ($2-$7)/$2*100}'`
	echo $cpu_status > ./info.txt
	echo $mem_status >> ./info.txt
	# printf "%s\n",$mem_status
	sleep 1s
done