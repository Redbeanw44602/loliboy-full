#!/bin/bash

if [ "$1"x = "cpu"x ]
then
	sed -n '1p' ./info.txt
else
	sed -n '2p' ./info.txt
fi