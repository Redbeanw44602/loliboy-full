#pragma once
#include <lang_detect.h>
#if LANG == CN
#  define M_QUERY_STR "§b%s 的余额为 %d"
#  define M_SET_STR "§b成功将 %s 的余额设置为 %d"
#  define M_PAY_STR "§b输入数值过大或过小(最大转账数50000，更大请分次转)"
#else
#  define M_QUERY_STR "§b%s 's money is %d"
#  define M_SET_STR "§bsucceed to set %s 's money to %d"
#  define M_PAY_STR "§bToo big or small money.Maximum is 50000."
#endif